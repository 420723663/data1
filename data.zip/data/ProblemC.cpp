#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
#include <iostream>
using namespace std;

pthread_mutex_t m[5];

void* eat(void *arg)
{
	long long i = (long long)arg;
	int left,right;
	if(i == 4){
		//make it a circle
		left = 0;
		right = i;
	}
	else{
		left = i;
		right = i+1;
	}
	while (1) {
		sleep(1);
		pthread_mutex_lock(&m[left]);
		int ret = pthread_mutex_trylock(&m[right]); 	
		if(ret != 0){
			//try to 
			pthread_mutex_unlock(&m[left]);
			cout << "phil " << i << " fails to get the forks...\n";
			//printf("phil %d fails to get the forks...\n",i);
			continue;
		}
		//get forks
		//printf("phil %d is eating...\n",i);
		cout << "phil " << i << " is eating...\n";
		//release forks
		pthread_mutex_unlock(&m[left]);
		pthread_mutex_unlock(&m[right]);
		//sleep(1);
	}
}

int main()
{
	pthread_t pth[5];
	//init
	for(int i = 0;i < 5;i++){
		pthread_mutex_init(&m[i],NULL);
	}
	//5 threads represents 5 phils
	for(int i = 0;i < 5;i++){
		pthread_create(&pth[i],NULL,eat,(void*)i);
	}
	//release 
	for(int i = 0;i < 5;i++){
		pthread_join(pth[i],NULL);
	}
	//exit
	pthread_exit(NULL);
	return 0;
}


