## OSP-2150-PrgAsg1

Name: 

Student ID:

Github link:

Illustration: to get the answer, make and run ProblemA.exe and ProblemC.exe

### Problem A: The Producer-Consumer Problem 

Problem Description:

Create an array of size 10 which are "buckets" that hold items that have been produced -e.g., random numbers, random strings, etc. Have five threads that are concurrently producing items to fill the available buckets and five threads that are concurrently consuming those items -say, printing them out to the screen would be fine. Have the program run for 10 seconds and then clean-up and exit without crashes, race conditions or deadlocks. 

Insights:

There are several constraints:

1. the producer can't produce if the buffer is full;
2. the consumer can't consume if the buffer is empty;
3. the consumer can't consume the item that has not been produced by the producers.

We use mutex lock to aviod deadlock, starvation, etc. 

Code:

```c++

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#include <iostream>
using namespace std;

#define M 10 // buffer length = 10
int in = 0;   
int out = 0; 
int buff[M] = {0};
bool flag; 
//Semaphores
sem_t sem1; // Synchronous
sem_t sem2;   // Synchronous signal
pthread_mutex_t mutex;// mutex sem

int ProducerId = 0;   //producer id
int ConsumerId = 0; //consumer id

//the producer method
void *produce(void *arg)
{
    int id = ++ProducerId;
    int number; 
    while(flag)
    {
        sleep(1);
        sem_wait(&sem1);
        pthread_mutex_lock(&mutex);
        number=rand()%10;
        buff[in]=number; 
        cout << "Producer " << id << "produces " <<  buff[in] << "\n"; 
        //printf("producer %d produces %d\n",id,buff[in]);
        in = in % M;
        ++in;
        pthread_mutex_unlock(&mutex);
        sem_post(&sem2);
    }
}


//the consumer method
void *consume(void *arg)
{
    int id = ++ConsumerId;
    while(flag)
    {
        sleep(1);
        sem_wait(&sem2);
        pthread_mutex_lock(&mutex);  
        cout << "Consumer " << id << "consumes " <<  buff[out] << "\n"; 
        //printf("Consumer %d consumes %d\n",id,buff[out]);
        out = out % M;
        ++out;    
        pthread_mutex_unlock(&mutex);
        sem_post(&sem1);
    }
}


int main()
{
    flag = true;
    pthread_t id1[5];
    pthread_t id2[5];
    int i;
    //init sem
    sem_init(&sem1, 0, M);
    sem_init(&sem2, 0, 0);
    pthread_mutex_init(&mutex, NULL);
    //create 5 producer threads
    for(i = 0; i < 5; i++)
    {
        pthread_create(&id1[i], NULL, produce, NULL);
    }
    //create 5 consumer threads
    for(i = 0; i < 5; i++)
    {
        pthread_create(&id2[i], NULL, consume , NULL);
    }
    sleep(10);
    flag = false;
    //release
    for( i = 0 ; i < 5; i++){
        pthread_join(id1[i],NULL);
    }
    for( i = 0 ; i < 2 ; i++){
        pthread_join(id2[i],NULL);
    }
    return 0;
    exit(0);
}
```

Compile code:

```
g++ ProblemA.cpp -lpthread -o ProblemA -Istdc++
```



### The Dining Philosophers' Problem

This problem models needing two of a particular resource in order to complete a task. A suggested solution is as follows: 

•create an array of 'forks' -say, five fork objects (for this exercise, these should be mutex locks). 

•create an array of threads, the same amount as the number of forks. 

•for the required duration of the program, say ten seconds: 

o sleep(‘think’)for a random number of milliseconds and try to grab the first fork(C1for the first philosopher, C2for the second philosopher, etc). If it is not available, sleep for a random number of milliseconds and try again. 

o sleep (‘think’)for a random number of milliseconds and try to grab the second fork (for thread 0, that would be lock 4 (wrap around to the largest lock), for thread 1 that would be lock 0, etc). 

o Once both locks have been attained, sleep (‘eat’)for a random number of milliseconds and then release both locks. 

DI: The above does NOT resolve deadlock in allcases.  Find and Fix it so that it does.HD: The algorithm is not always fait in that some philosophers can get to eat more than others due to timing and sequence.  Make it fair. 

Insight:

we use 5 threads to represent 5 philosophers. We use mutex lock to aviod deadlock, starvation, etc.  Each time a philosopher is guaranteed to eat, when the philosopher wants to eat, first test the lock, if he can get the lock, then tests his own forks and the chopsticks on the right, if he can, then pick up the forks to eat, otherwise blocking, when a philosopher thinks, he tests whether he can acquire a Mutex, and if he can, he puts down his forks and the one on the right.   

Code:

```c++
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
#include <iostream>
using namespace std;

pthread_mutex_t m[5];

void* eat(void *arg)
{
	long long i = (long long)arg;
	int left,right;
	if(i == 4){
		//make it a circle
		left = 0;
		right = i;
	}
	else{
		left = i;
		right = i+1;
	}
	while (1) {
		sleep(1);
		pthread_mutex_lock(&m[left]);
		int ret = pthread_mutex_trylock(&m[right]); 	
		if(ret != 0){
			//try to 
			pthread_mutex_unlock(&m[left]);
			cout << "phil " << i << " fails to get the forks...\n";
			//printf("phil %d fails to get the forks...\n",i);
			continue;
		}
		//get forks
		//printf("phil %d is eating...\n",i);
		cout << "phil " << i << " is eating...\n";
		//release forks
		pthread_mutex_unlock(&m[left]);
		pthread_mutex_unlock(&m[right]);
		//sleep(1);
	}
}

int main()
{
	pthread_t pth[5];
	//init
	for(int i = 0;i < 5;i++){
		pthread_mutex_init(&m[i],NULL);
	}
	//5 threads represents 5 phils
	for(int i = 0;i < 5;i++){
		pthread_create(&pth[i],NULL,eat,(void*)i);
	}
	//release 
	for(int i = 0;i < 5;i++){
		pthread_join(pth[i],NULL);
	}
	//exit
	pthread_exit(NULL);
	return 0;
}



```

Compile code:

```
g++ ProblemC.cpp -lpthread -o ProblemC -Istdc++
```

