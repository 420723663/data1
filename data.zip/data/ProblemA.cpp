
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#include <iostream>
using namespace std;

#define M 10 // buffer length = 10
int in = 0;   
int out = 0; 
int buff[M] = {0};
bool flag; 
//Semaphores
sem_t sem1; // Synchronous
sem_t sem2;   // Synchronous signal
pthread_mutex_t mutex;// mutex sem

int ProducerId = 0;   //producer id
int ConsumerId = 0; //consumer id

//the producer method
void *produce(void *arg)
{
    int id = ++ProducerId;
    int number; 
    while(flag)
    {
        sleep(1);
        sem_wait(&sem1);
        pthread_mutex_lock(&mutex);
        number=rand()%10;
        buff[in]=number; 
        cout << "Producer " << id << "produces " <<  buff[in] << "\n"; 
        //printf("producer %d produces %d\n",id,buff[in]);
        in = in % M;
        ++in;
        pthread_mutex_unlock(&mutex);
        sem_post(&sem2);
    }
}


//the consumer method
void *consume(void *arg)
{
    int id = ++ConsumerId;
    while(flag)
    {
        sleep(1);
        sem_wait(&sem2);
        pthread_mutex_lock(&mutex);  
        cout << "Consumer " << id << "consumes " <<  buff[out] << "\n"; 
        //printf("Consumer %d consumes %d\n",id,buff[out]);
        out = out % M;
        ++out;    
        pthread_mutex_unlock(&mutex);
        sem_post(&sem1);
    }
}


int main()
{
    flag = true;
    pthread_t id1[5];
    pthread_t id2[5];
    int i;
    //init sem
    sem_init(&sem1, 0, M);
    sem_init(&sem2, 0, 0);
    pthread_mutex_init(&mutex, NULL);
    //create 5 producer threads
    for(i = 0; i < 5; i++)
    {
        pthread_create(&id1[i], NULL, produce, NULL);
    }
    //create 5 consumer threads
    for(i = 0; i < 5; i++)
    {
        pthread_create(&id2[i], NULL, consume , NULL);
    }
    sleep(10);
    flag = false;
    //release
    for( i = 0 ; i < 5; i++){
        pthread_join(id1[i],NULL);
    }
    for( i = 0 ; i < 2 ; i++){
        pthread_join(id2[i],NULL);
    }
    return 0;
    exit(0);
}